<footer class="py-5 mt-5">
    <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top">
        <div class="container">
            <p>© 2023 MIN INFORMATION AND TECHNOLOGY. All rights reserved.</p>
        </div>
    </div>
</footer>
