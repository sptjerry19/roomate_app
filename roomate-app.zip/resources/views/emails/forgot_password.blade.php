<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Đặt lại mã xác minh mật khẩu</title>
</head>

<body>
    <h2>Xin chào!</h2>
    <p>Bạn nhận được email này vì chúng tôi đã nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn.</p>

    <p><strong>Mã xác nhận của bạn là:</strong></p>
    <p>{{ $verificationCode }}</p>

    <p>Nếu bạn không yêu cầu đặt lại mật khẩu thì không cần thực hiện thêm hành động nào.</p>

    <p>Regards,<br>carlink</p>
</body>

</html>
