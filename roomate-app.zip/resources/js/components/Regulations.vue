<template>
    <div class="mx-auto px-12 py-6">
        <p>
            <span style="font-size: 15pt; font-family: 'Times New Roman', serif"
                >QUY ĐỊNH ĐĂNG TIN TR&Ecirc;N AA+ HOME</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >AA+ Home l&agrave; nền tảng hỗ trợ kết nối người c&oacute; nhu
                cầu thu&ecirc; trọ, t&igrave;m roommate với chủ nh&agrave; hoặc
                người cho thu&ecirc; trọ tại khu vực miền Bắc. Để đảm bảo
                m&ocirc;i trường th&ocirc;ng tin minh bạch, chất lượng v&agrave;
                c&oacute; lợi cho tất cả người d&ugrave;ng, ch&uacute;ng
                t&ocirc;i đưa ra c&aacute;c quy định đăng tin như sau:</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >1. Quy định chung</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.1. Tin đăng phải li&ecirc;n quan đến lĩnh vực thu&ecirc; trọ,
                t&igrave;m roommate hoặc c&aacute;c dịch vụ hỗ trợ li&ecirc;n
                quan.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.2. Nội dung tin đăng phải ch&iacute;nh x&aacute;c, r&otilde;
                r&agrave;ng, kh&ocirc;ng g&acirc;y hiểu lầm hoặc chứa
                th&ocirc;ng tin sai lệch.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.3. Kh&ocirc;ng đăng tin vi phạm ph&aacute;p luật, tr&aacute;i
                với thuần phong mỹ tục hoặc g&acirc;y ảnh hưởng ti&ecirc;u cực
                đến cộng đồng.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.4. Kh&ocirc;ng đăng tin chứa nội dung quảng c&aacute;o, tiếp
                thị kh&ocirc;ng li&ecirc;n quan đến lĩnh vực của AA+ Home.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.5. Kh&ocirc;ng đăng tin tr&ugrave;ng lặp trong thời gian
                ngắn.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >2. Ti&ecirc;u chuẩn nội dung tin đăng</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.1. Ti&ecirc;u đề: Phải thể hiện đ&uacute;ng nội dung tin
                đăng, kh&ocirc;ng chứa k&yacute; tự đặc biệt hoặc từ ngữ
                g&acirc;y hiểu lầm.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.2. Nội dung:</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Cung cấp đầy đủ th&ocirc;ng tin về ph&ograve;ng trọ, căn hộ,
                nh&agrave; ở hoặc nhu cầu t&igrave;m roommate.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Ghi r&otilde; địa chỉ khu vực (phường/x&atilde;, quận/huyện,
                th&agrave;nh phố).</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >N&ecirc;u r&otilde; gi&aacute; thu&ecirc;, diện t&iacute;ch, số
                người ở tối đa, tiện &iacute;ch đi k&egrave;m.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.3. H&igrave;nh ảnh:</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >H&igrave;nh ảnh phải ch&acirc;n thực, kh&ocirc;ng chỉnh sửa
                qu&aacute; mức l&agrave;m sai lệch thực tế.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Kh&ocirc;ng sử dụng h&igrave;nh ảnh chứa logo, watermark của
                website kh&aacute;c.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >3. Quy định về t&agrave;i khoản v&agrave; li&ecirc;n
                    hệ</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >3.1. Người đăng tin phải sử dụng t&agrave;i khoản thật, cung
                cấp th&ocirc;ng tin li&ecirc;n hệ ch&iacute;nh x&aacute;c.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >3.2. Kh&ocirc;ng được sử dụng nhiều t&agrave;i khoản để đăng
                tin tr&ugrave;ng lặp.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >3.3. Kh&ocirc;ng được đăng tải số điện thoại, email giả mạo
                hoặc th&ocirc;ng tin của b&ecirc;n thứ ba m&agrave; kh&ocirc;ng
                c&oacute; sự cho ph&eacute;p.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >4. H&igrave;nh thức xử l&yacute; vi phạm</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >AA+ Home c&oacute; quyền kiểm duyệt, từ chối hoặc x&oacute;a
                c&aacute;c tin đăng vi phạm quy định m&agrave; kh&ocirc;ng cần
                th&ocirc;ng b&aacute;o trước. Những t&agrave;i khoản cố
                t&igrave;nh vi phạm nhiều lần c&oacute; thể bị kh&oacute;a hoặc
                cấm đăng tin vĩnh viễn.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Quy định n&agrave;y c&oacute; hiệu lực từ
                [ng&agrave;y/th&aacute;ng/năm] v&agrave; c&oacute; thể được cập
                nhật t&ugrave;y theo ch&iacute;nh s&aacute;ch của AA+
                Home.</span
            >
        </p>
        <p><br /></p>
        <p>
            <span style="font-size: 15pt; font-family: 'Times New Roman', serif"
                >QUY CHẾ HOẠT ĐỘNG CỦA WEBSITE AA+ HOME</span
            >
        </p>
        <p><br /></p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Ch&uacute;ng t&ocirc;i cam kết mang đến một m&ocirc;i trường
                minh bạch, hiệu quả v&agrave; an to&agrave;n cho c&aacute;c
                b&ecirc;n tham gia.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Để đảm bảo quyền lợi v&agrave; nghĩa vụ của tất cả người
                d&ugrave;ng, AA+ Home ban h&agrave;nh Quy chế hoạt động như
                sau:</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >1. Nguy&ecirc;n tắc chung</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.1. AA+ Home hoạt động theo quy định của ph&aacute;p luật Việt
                Nam, đảm bảo t&iacute;nh c&ocirc;ng khai, minh bạch v&agrave;
                t&ocirc;n trọng quyền lợi của người d&ugrave;ng.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.2. Mọi c&aacute; nh&acirc;n, tổ chức tham gia giao dịch
                tr&ecirc;n AA+ Home phải tu&acirc;n thủ c&aacute;c điều khoản
                trong Quy chế hoạt động n&agrave;y.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >1.3. C&aacute;c giao dịch li&ecirc;n quan đến thu&ecirc; trọ,
                t&igrave;m roommate được thực hiện trực tiếp giữa c&aacute;c
                b&ecirc;n. AA+ Home chỉ đ&oacute;ng vai tr&ograve; trung gian
                cung cấp nền tảng đăng tin, kh&ocirc;ng chịu tr&aacute;ch nhiệm
                về nội dung tin đăng cũng như kết quả giao dịch giữa c&aacute;c
                b&ecirc;n.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >2. Quy định về t&agrave;i khoản v&agrave; người
                    d&ugrave;ng</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.1. Người d&ugrave;ng khi đăng k&yacute; t&agrave;i khoản
                tr&ecirc;n AA+ Home cần cung cấp th&ocirc;ng tin ch&iacute;nh
                x&aacute;c, đầy đủ.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.2. Mỗi người d&ugrave;ng chỉ được ph&eacute;p sử dụng một
                t&agrave;i khoản duy nhất. Việc sử dụng nhiều t&agrave;i khoản
                để đăng tin tr&ugrave;ng lặp hoặc c&oacute; h&agrave;nh vi gian
                lận sẽ bị xử l&yacute;.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >2.3. Người d&ugrave;ng chịu tr&aacute;ch nhiệm bảo mật
                th&ocirc;ng tin t&agrave;i khoản, kh&ocirc;ng chia sẻ t&agrave;i
                khoản với người kh&aacute;c.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >3. Quy tr&igrave;nh đăng tin v&agrave; giao dịch</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >3.1. Đối với người đăng tin</span
            >
        </p>
        <p><br /></p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Cung cấp đầy đủ th&ocirc;ng tin về ph&ograve;ng trọ, căn hộ,
                nh&agrave; ở hoặc nhu cầu t&igrave;m roommate.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Nội dung tin đăng phải r&otilde; r&agrave;ng, trung thực,
                kh&ocirc;ng g&acirc;y hiểu lầm.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Kh&ocirc;ng đăng tin vi phạm ph&aacute;p luật, thuần phong mỹ
                tục hoặc chứa nội dung quảng c&aacute;o kh&ocirc;ng li&ecirc;n
                quan.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >H&igrave;nh ảnh đ&iacute;nh k&egrave;m phải thực tế,
                kh&ocirc;ng bị chỉnh sửa qu&aacute; mức.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >3.2. Đối với người t&igrave;m thu&ecirc; trọ, t&igrave;m
                roommate</span
            >
        </p>
        <p><br /></p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >Tự t&igrave;m hiểu kỹ th&ocirc;ng tin trước khi li&ecirc;n hệ
                hoặc thực hiện giao dịch.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >AA+ Home khuyến nghị gặp trực tiếp chủ nh&agrave;/người cho
                thu&ecirc; để kiểm tra thực tế trước khi đặt cọc hoặc k&yacute;
                hợp đồng.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >B&aacute;o c&aacute;o với AA+ Home nếu ph&aacute;t hiện tin
                đăng sai sự thật hoặc c&oacute; dấu hiệu lừa đảo.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >4. Tr&aacute;ch nhiệm v&agrave; cam kết của AA+ Home</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >4.1. Cung cấp nền tảng đăng tin hoạt động ổn định, hỗ trợ người
                d&ugrave;ng trong qu&aacute; tr&igrave;nh t&igrave;m kiếm
                th&ocirc;ng tin.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >4.2. Kiểm duyệt tin đăng nhằm hạn chế tin sai sự thật hoặc vi
                phạm quy định.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >4.3. Hỗ trợ người d&ugrave;ng giải quyết c&aacute;c vấn đề
                ph&aacute;t sinh li&ecirc;n quan đến tin đăng khi nhận được phản
                hồi.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >4.4. Kh&ocirc;ng chịu tr&aacute;ch nhiệm về bất kỳ thiệt hại
                n&agrave;o ph&aacute;t sinh từ giao dịch giữa c&aacute;c
                b&ecirc;n sử dụng nền tảng AA+ Home.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >5. Cơ chế giải quyết tranh chấp</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >5.1. Nếu xảy ra tranh chấp giữa c&aacute;c b&ecirc;n, AA+ Home
                khuyến kh&iacute;ch tự thương lượng để giải quyết.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >5.2. Trong trường hợp cần thiết, AA+ Home c&oacute; thể hỗ trợ
                cung cấp th&ocirc;ng tin li&ecirc;n quan để c&aacute;c b&ecirc;n
                giải quyết tranh chấp.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >5.3. Mọi tranh chấp ph&aacute;t sinh sẽ được xử l&yacute; theo
                quy định ph&aacute;p luật Việt Nam.</span
            >
        </p>
        <p><br /></p>
        <p>
            <strong
                ><span
                    style="
                        font-size: 12pt;
                        font-family: 'Times New Roman', serif;
                    "
                    >6. Điều khoản &aacute;p dụng</span
                ></strong
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >6.1. Quy chế n&agrave;y c&oacute; hiệu lực từ
                [ng&agrave;y/th&aacute;ng/năm] v&agrave; c&oacute; thể được cập
                nhật t&ugrave;y theo ch&iacute;nh s&aacute;ch của AA+
                Home.</span
            >
        </p>
        <p>
            <span style="font-size: 12pt; font-family: 'Times New Roman', serif"
                >6.2. Người d&ugrave;ng khi sử dụng AA+ Home đồng nghĩa với việc
                đồng &yacute; tu&acirc;n thủ c&aacute;c điều khoản trong Quy chế
                n&agrave;y.</span
            >
        </p>
    </div>
</template>
