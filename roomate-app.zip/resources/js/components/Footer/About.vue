<template>
    <nav class="fixed top-0 left-0 z-20 w-full bg-white py-2.5 px-4 shadow-md">
        <div class="container mx-auto flex items-center justify-between">
            <!-- Logo and Dropdown -->
            <div class="flex items-center space-x-3">
                <router-link to="/">
                    <img
                        src="https://s3-alpha-sig.figma.com/img/94aa/de1b/7c2686b66c34627c8e323577a00ecd80?Expires=1740355200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=Ex3TtLJcraaGGZJf0Y7z8znbGyYjk5v~jsAocqgG4S6yb9XTHaoeW7vwIQrtxeJfTrbtYSYLeDmxPx7S1EtUkysukNdYrYKCREcKsHI8ExlpdcK2OGYKSf3IcXWN3wYXEIn5anDZeWBRnwjttsdhUk5jTSrP7Iv55dRROUCR4D4ttmgEmNXWXzHolaetcxGHSLSjet1prJG61EK0mux6O5AM1s3CLMLxc~EgOV-iGhOiGZGjGzEoQh~sCXgs~e6uAK~dem-48WN9YhwRRaxLKkv23M5QaoVYCL92mrKu9eZGwdkq5hT44H4pR1IYUNEvf~XiKSDqBjCDPxlmevxnGQ__"
                        alt="Logo"
                        class="h-8 w-8 object-contain"
                    />
                </router-link>
            </div>
        </div>
    </nav>
    <div class="mx-auto mt-40 w-3/4">
        <div class="bg-white p-8 rounded-lg shadow-md">
            <h1 class="text-3xl font-bold text-center mb-4">
                GIỚI THIỆU VỀ AA+ HOME
            </h1>
            <p class="text-center text-gray-700 mb-6">
                Chào mừng bạn đến với AA+ Home – nền tảng kết nối nhanh chóng
                giữa người cho thuê và người tìm trọ!
            </p>
            <p class="text-gray-700 mb-6">
                AA+ Home ra đời nhằm giúp bạn tìm kiếm phòng trọ, căn hộ mini dễ
                dàng, minh bạch và tiết kiệm thời gian. Với giao diện thân
                thiện, hệ thống định vị chính xác và thông tin phòng trọ được
                kiểm duyệt kỹ lưỡng, chúng tôi mang đến trải nghiệm tìm kiếm tối
                ưu nhất.
            </p>
            <div class="flex justify-center mb-6">
                <img
                    alt="Illustration of people using AA+ Home platform"
                    class="w-full max-w-md"
                    height="400"
                    src="https://s3-alpha-sig.figma.com/img/ae60/c12c/32ee19ec550a3d09e98278dd75e82cee?Expires=1740960000&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=dO0qpf5GIEcn7v1XCuJWzgCNNeB4imGdUi66x5L49Gv0iHwcMmCqzUcu~-ncBdsDYnuqPWI9wjfTbseDyZu-s2FI-xLNLTowXGoJ74R1~EXk6EEN~5YzNEUg4NvF8gLphLysjOGMrObwUPyX6auyMCSOgdftKJkzZYENcZ5ctlozodzs2Vo8szen8LM~mf1heQ2wQR16VyxBfNVoebxsolGVb9-uVBkPJeuPIQpdTrF2LqObG2M-9iT0TqElKGGGCjdYCuNcwVL68SpLESaZZcoEI4KEQljKmHfgnCVfDN9dqD6ULEEH6T2WqBptEv87X-KS5YZqb6~eWY9CNeNYvA__"
                    width="600"
                />
            </div>
            <h2 class="text-2xl font-bold mb-4">Tại sao chọn AA+ Home?</h2>
            <ul class="list-disc list-inside text-gray-700 mb-6">
                <li>
                    Nguồn phòng trọ đa dạng – Cập nhật liên tục, phù hợp với
                    nhiều nhu cầu khác nhau.
                </li>
                <li>
                    Thông tin minh bạch – Hình ảnh thực tế, giá cả rõ ràng, đánh
                    giá từ người thuê trước.
                </li>
                <li>
                    Kết nối nhanh chóng – Liên hệ trực tiếp với chủ trọ, hẹn gặp
                    ngay.
                </li>
                <li>
                    Tìm roommate dễ dàng – Ghép trọ với những người có sở thích,
                    phong cách sống.
                </li>
            </ul>
            <h2 class="text-2xl font-bold mb-4">Các dịch vụ chính</h2>
            <ul class="list-disc list-inside text-gray-700 mb-6">
                <li>
                    Tìm kiếm phòng trọ: Cung cấp danh sách phòng trọ, căn hộ
                    mini trên toàn quốc với các tiêu chí rõ ràng như giá cả, vị
                    trí, tiện ích, tiện lợi, dễ tìm kiếm.
                </li>
                <li>
                    Cho thuê phòng trọ: Hỗ trợ chủ nhà đăng tin cho thuê phòng
                    nhanh chóng, dễ dàng tiếp cận nhiều khách thuê tiềm năng.
                </li>
                <li>
                    Tìm roommate: Giúp người thuê kết nối với những bạn cùng
                    phòng phù hợp, tiết kiệm chi phí và môi trường sống thoải
                    mái nhất.
                </li>
                <li>
                    Đánh giá &amp; phản hồi: Người dùng có thể để lại đánh giá
                    về phòng trọ, giúp cộng đồng có cái nhìn chính xác trước khi
                    quyết định thuê.
                </li>
                <li>
                    Hỗ trợ và tư vấn: Cung cấp thông tin về hợp đồng thuê trọ,
                    kinh nghiệm tìm phòng, xử lý các vấn đề khi thuê nhà.
                </li>
            </ul>
            <h2 class="text-2xl font-bold mb-4">Thông tin về website</h2>
            <ul class="list-none text-gray-700 mb-6">
                <li>
                    Website:
                    <a
                        class="text-blue-600 hover:underline"
                        href="http://aaphome.click/"
                    >
                        http://aahome.click/
                    </a>
                </li>
                <li>Địa chỉ: Khu Công nghệ cao Hòa Lạc, Thạch Thất, Hà Nội</li>
                <li>Số điện thoại: 0867743399</li>
                <li>
                    Email:
                    <a
                        class="text-blue-600 hover:underline"
                        href="mailto:Aaplushome@gmail.com"
                    >
                        Aaplushome@gmail.com
                    </a>
                </li>
                <li>
                    Chăm sóc khách hàng:
                    <a
                        class="text-blue-600 hover:underline"
                        href="mailto:cskhaaplushome@gmail.com"
                    >
                        cskhaaplushome@gmail.com
                    </a>
                </li>
            </ul>
        </div>
    </div>
</template>
